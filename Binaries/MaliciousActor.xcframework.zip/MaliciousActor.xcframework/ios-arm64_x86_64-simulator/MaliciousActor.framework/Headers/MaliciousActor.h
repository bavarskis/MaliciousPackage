//
//  MaliciousActor.h
//  MaliciousActor
//
//  Created by Aurimas Bavarskis on 28/09/2023.
//

#import <Foundation/Foundation.h>

// Based on: https://vimeo.com/865559955

//! Project version number for MaliciousActor.
FOUNDATION_EXPORT double MaliciousActorVersionNumber;

//! Project version string for MaliciousActor.
FOUNDATION_EXPORT const unsigned char MaliciousActorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MaliciousActor/PublicHeader.h>


